#!/bin/bash
for i in `find . -name '*.d'`
do
    if [ ! "`grep 'std\.compat' $i`" ]
    then
        perl -pe 's/^(module .*)$/\1\nimport std.compat;/' -i $i
    fi
done

